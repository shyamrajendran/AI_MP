package war_game;

/**
 * Created by manshu on 3/14/15.
 */
public enum Player {
    BLUE, // MAX Player
    GREEN // MIN Player
}
