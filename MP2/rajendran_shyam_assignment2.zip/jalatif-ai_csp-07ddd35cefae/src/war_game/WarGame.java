package war_game;

/**
 * Created by manshu on 3/26/15.
 */

import org.lwjgl.Sys;
import org.newdawn.slick.*;
import org.newdawn.slick.font.effects.ColorEffect;

import java.util.List;
import java.util.Set;

public class WarGame extends BasicGame {
    private Color ICOLOR = new Color(13, 124, 222);
    private int screen_height, screen_width;
    private int width = 200, height = 200;
    private int score_height = 100;
    private int margin = 25;
    private int text_size = 35;
    private int grsize = 6, gcsize = 6;
    private Music war_music;
    private Image button, button_pause, music_on, music_off;
    private UnicodeFont font;
    private int ratio;
    private int p1_score = 0, p2_score = 0;
    private boolean paused = true, music_paused = true;
    private int board[][];
    private int[][] grid;
    private Player current_player;
    private Player user_player;
    private boolean isUserTurn;
    private volatile Tuple user_input;

    public WarGame() throws SlickException {
        super("War Game");
        grid = new int[grsize][gcsize];
        user_player = Player.BLUE;
        isUserTurn = true;
        user_input = null;

        this.board = new int[grsize][gcsize];
        current_player = Player.BLUE;
        screen_width = gcsize * width + margin * (gcsize + 1);
        screen_height = grsize * height + margin * (grsize + 1) + score_height;
        System.out.println(screen_width + " " + screen_height);
    }

    public WarGame(int[][] board) throws SlickException {
        super("War Game");
        user_player = Player.BLUE;
        if (board.length != grsize || board[0].length != gcsize) {
            grsize = board.length;
            gcsize = board[0].length;
        }
        this.board = board;
        current_player = Player.BLUE;
        isUserTurn = true;
        user_input = null;

        grid = new int[grsize][gcsize];
        screen_width = gcsize * width + margin * (gcsize + 1);
        screen_height = grsize * height + margin * (grsize + 1) + score_height;
        System.out.println(screen_width + " " + screen_height);
    }

    public Tuple getUserInput() {
        while (user_input == null) {}
        Tuple temp = user_input;
        user_input = null;
        return temp;
    }
    public void setBoard(BoardState boardState) {
        if (boardState.getPlayer() == Player.BLUE) {
            p2_score = boardState.getPlayerScore(boardState.getPlayer());
            p1_score = boardState.getPlayerScore(boardState.getOtherPlayer());
        } else {
            p1_score = boardState.getPlayerScore(boardState.getPlayer());
            p2_score = boardState.getPlayerScore(boardState.getOtherPlayer());
        }

        Set<Tuple> p1_locations = boardState.getPlayerInfo(boardState.getPlayer());
        Set<Tuple> p2_locations = boardState.getPlayerInfo(boardState.getOtherPlayer());

        for (Tuple tuple : p1_locations) {
            grid[tuple.getRow()][tuple.getCol()] = boardState.getOtherPlayer().ordinal() + 1;
        }
        for (Tuple tuple : p2_locations) {
            grid[tuple.getRow()][tuple.getCol()] = boardState.getPlayer().ordinal() + 1;
        }
        current_player = boardState.getPlayer();
        if (current_player == user_player) isUserTurn = true;
        else isUserTurn = false;
    }

    public int getScreenHeight() {
        return screen_height;
    }

    public int getScreenWidth() {
        return screen_width;
    }

    @Override
    public void init(GameContainer gameContainer) throws SlickException {
        war_music = new Music("resources/wargame_intro.ogg");
        button = new Image("resources/button.png");
        button_pause = new Image("resources/button_pause.png");
        music_on = new Image("resources/music_on.png");
        music_off = new Image("resources/music_off.png");

        ratio = button.getWidth() / button.getHeight();
//
//        war_music.loop();
        font = new UnicodeFont(new java.awt.Font ("comicsansms", java.awt.Font.BOLD, text_size));
        font.getEffects().add(new ColorEffect(java.awt.Color.white));
        font.addNeheGlyphs();
        font.loadGlyphs();
    }

    @Override
    public void update(GameContainer gameContainer, int i) throws SlickException {
        Input input = gameContainer.getInput();

        if (input.isMousePressed(input.MOUSE_LEFT_BUTTON)) {
            int mouse_x = input.getMouseX();
            int mouse_y = input.getMouseY();
            if (mouse_y <= score_height) {
                if (mouse_x >= (screen_width - ratio * button.getWidth())) {
                    // && ((score_height - button.getHeight()) / 2) <= mouse_y && mouse_y <= ((score_height + button.getHeight()) / 2))
                    paused = !paused;
                }
                if (mouse_x <= ratio * button.getWidth()) {
                    music_paused = !music_paused;
                    if (music_paused) war_music.pause();
                    else war_music.play();
                }
            } else {
                int col = mouse_x / (width + margin);
                int row = (mouse_y - score_height) / (height + margin);
                if (isUserTurn) {
                    if (!paused && row >= 0 && grid[row][col] == 0) {
                        if (current_player == Player.BLUE) {
                            grid[row][col] = 1;
                            p1_score += board[row][col];
                            current_player = Player.GREEN;
                        } else {
                            grid[row][col] = 2;
                            p2_score += board[row][col];
                            current_player = Player.BLUE;
                        }
                        user_input = new Tuple(row, col);
                    }
                    isUserTurn = false;
                }
                System.out.println("Click (" + mouse_x + ", " + mouse_y + ") Grid coordinates: " + row + " " + col);
            }

        }
    }

    @Override
    public void render(GameContainer gameContainer, Graphics graphics) throws SlickException {
        graphics.setFont(font);
        graphics.setBackground(Color.black);
        graphics.setColor(ICOLOR);
        graphics.fillRect(0, 0, screen_width, score_height);
        String bturn = "", gturn = "";
        if (isUserTurn) bturn = "(*)";
        else gturn = "(*)";

        String score_text = bturn + "Blue's Score = " + String.valueOf(p1_score) + ", " + gturn +
                "Green's Score = " + String.valueOf(p2_score);

        font.drawString((screen_width - font.getWidth(score_text)) / 2, (score_height - font.getHeight(score_text)) / 2,
                score_text, Color.black);

        if (paused) {
            graphics.drawImage(button, screen_width - ratio * button.getWidth(), 0, screen_width, score_height,
                0, 0, button.getWidth(), button.getHeight());
        }
        else {
            graphics.drawImage(button_pause, screen_width - ratio * button_pause.getWidth(), 0, screen_width, score_height,
                    0, 0, button_pause.getWidth(), button_pause.getHeight());
        }

        if (music_paused) {
            graphics.drawImage(music_on, 0, 0, ratio * music_on.getWidth(), score_height,
                    0, 0, music_on.getWidth(), music_on.getHeight());
        }
        else {
            graphics.drawImage(music_off, 0, 0, ratio * music_off.getWidth(), score_height,
                    0, 0, music_off.getWidth(), music_off.getHeight());
        }

        for (int row = 0; row < grsize; row++) {
            for (int col = 0; col < gcsize; col++) {
                Color color = Color.white;
                if (grid[row][col] == 1)
                    color = Color.green;
                else if (grid[row][col] == 2)
                    color = Color.blue;

                graphics.setColor(Color.white);
                graphics.fillRect((margin + width) * col + margin, (margin + height) * row + margin + score_height,
                        width, height);


                if (color != Color.white) {
                    graphics.setColor(Color.black);
                    graphics.fillOval((margin + width) * col + margin, (margin + height) * row + margin + score_height,
                            width, height);
                    graphics.setColor(color);
                    graphics.fillOval((margin + width) * col + margin + 20,
                            (margin + height) * row + margin + score_height + 20, width - 40, height - 40);
                }
                Color text_color = Color.black;
                if (color != Color.white) text_color = Color.white;
                String text = String.valueOf(board[row][col]);
                font.drawString((margin + width) * col + margin + (width - font.getWidth(text)) / 2,
                        (margin + height) * row + margin + score_height + (height - font.getHeight(text)) / 2,
                        text, text_color);
            }
        }


    }

    public static void main(String[] args) {
        try {
            WarGame game = new WarGame();
            AppGameContainer app = new AppGameContainer(game);
            app.setDisplayMode(game.getScreenWidth(), game.getScreenHeight(), false);
            app.setTargetFrameRate(29);
            app.start();
        }
        catch (SlickException e) {
            e.printStackTrace();
        }
    }
}

